findpython 1.0.5
================
* Minor internal refactoring and documentation improvements.

findpython 1.0.4
================
* No longer throws an unintended error when can't find a suitable python command AND ``reticulate`` package is not installed.

findpython 1.0.3
================
* Uses ``reticulate::py_discover_config`` to find more python
  binaries if can't otherwise find a suitable python command.

findpython 1.0.2
================
* Looks for more python binaries and likely folders in Windows (i.e. Python 3.5 through Python 3.9).  
  Thanks Jori Liesenborgs for request.

findpython 1.0.1
================
* Initial released version on CRAN.



