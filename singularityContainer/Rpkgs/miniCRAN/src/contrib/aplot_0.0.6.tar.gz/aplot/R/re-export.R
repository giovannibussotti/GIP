##' @importFrom ggplot2 ggsave
##' @export
ggplot2::ggsave

##' @importFrom magrittr %>%
##' @export
magrittr::`%>%`
