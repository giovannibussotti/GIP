library(testthat)
library(regioneR)

test_check("regioneR")
