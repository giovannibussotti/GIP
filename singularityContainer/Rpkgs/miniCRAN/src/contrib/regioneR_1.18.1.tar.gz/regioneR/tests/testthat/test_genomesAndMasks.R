library(regioneR)
context("Genomes and Masks")

#TODO
