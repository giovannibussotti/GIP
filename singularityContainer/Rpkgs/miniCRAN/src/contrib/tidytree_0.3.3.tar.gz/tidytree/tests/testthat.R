library(testthat)
library(tidytree)

test_check("tidytree")
