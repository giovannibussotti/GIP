library("testthat")
library("bamsignals")

test_check("bamsignals")
