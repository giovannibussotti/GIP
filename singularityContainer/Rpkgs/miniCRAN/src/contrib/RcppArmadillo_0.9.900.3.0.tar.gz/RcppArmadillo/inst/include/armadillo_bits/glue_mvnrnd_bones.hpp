// Copyright 2008-2016 Conrad Sanderson (http://conradsanderson.id.au)
// Copyright 2008-2016 National ICT Australia (NICTA)
// 
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
// http://www.apache.org/licenses/LICENSE-2.0
// 
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.
// ------------------------------------------------------------------------


//! \addtogroup glue_mvnrnd
//! @{


class glue_mvnrnd_vec
  {
  public:
  
  template<typename T1, typename T2>
  struct traits
    {
    static const bool is_row  = false;
    static const bool is_col  = true;
    static const bool is_xvec = false;
    };
  
  template<typename T1, typename T2>
  inline static void apply(Mat<typename T1::elem_type>& out, const Glue<T1,T2,glue_mvnrnd_vec>& expr);
  };



class glue_mvnrnd
  : public traits_glue_default
  {
  public:
  
  template<typename T1, typename T2>
  inline static void apply(Mat<typename T1::elem_type>& out, const Glue<T1,T2,glue_mvnrnd>& expr);
  
  template<typename T1, typename T2>
  inline static bool apply_direct(Mat<typename T1::elem_type>& out, const Base<typename T1::elem_type,T1>& M, const Base<typename T1::elem_type,T2>& C, const uword N);
  
  template<typename eT>
  inline static bool apply_noalias(Mat<eT>& out, const Mat<eT>& M, const Mat<eT>& C, const uword N);
  };



//! @}
