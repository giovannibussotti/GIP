library(testthat)
library(karyoploteR)

test_check("karyoploteR")
