# 
# Test of the dcount C function, used by some routines
#
