void Rprintvec(char*,double*,int);
void Rprintmat(char*,double**,int,int);
void RprintVecAsMat(char*,double*,int,int);
void RprintIvec(char*,int*,int);
void RprintImat(char*,int**,int,int);
void ProgressBar(int,int);
