double quform(double*,double*,int);
double biform(double*,double**,double*,int);
