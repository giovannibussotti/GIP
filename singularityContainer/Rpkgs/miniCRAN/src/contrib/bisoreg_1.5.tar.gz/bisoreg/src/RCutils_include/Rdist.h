void rmvnorm(double*,double*,int,double*,double*);
void rwish(int,double*,int,double*,double*,double*,double*);
double rtnorm(double,double,double,double);
double dmvnorm(double*,double*,double*,int,double,double*,int);
void R_rtnorm(int*,double*,double*,double*,double*,double*);
