# The robustness Subsystem of compositions




#robustnessBot <- function(what=c("mean","var","all","cov"),rob,x,...) {
  #
#
#}
